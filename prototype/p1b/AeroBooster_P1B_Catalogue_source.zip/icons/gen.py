import os
W,H=240,170
def card(body): return f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {W} {H}"><rect x="2" y="2" width="{W-4}" height="{H-4}" rx="10" fill="#fbfbfc" stroke="#9aa" stroke-width="2"/>{body}</svg>'
A="#1f4e79"; A2="#2e75b6"; G="#777"; R="#c0392b"; Y="#e0942f"
icons={
"tank":f'<rect x="78" y="40" width="84" height="92" fill="none" stroke="{A}" stroke-width="4"/><rect x="66" y="34" width="108" height="10" fill="{A}"/><path d="M78 60 h84 M78 80 h84" stroke="#bcd" stroke-width="2"/>',
"plate":f'<ellipse cx="120" cy="92" rx="78" ry="26" fill="#3a3a3a"/><ellipse cx="120" cy="86" rx="78" ry="26" fill="#555" stroke="#222" stroke-width="2"/><ellipse cx="120" cy="86" rx="60" ry="18" fill="none" stroke="#333" stroke-width="2"/>',
"band":f'<ellipse cx="120" cy="86" rx="70" ry="30" fill="none" stroke="{R}" stroke-width="12"/><ellipse cx="120" cy="86" rx="70" ry="30" fill="none" stroke="#7a1d12" stroke-width="2"/><path d="M120 116 l24 20" stroke="#333" stroke-width="3"/>',
"lid":f'<ellipse cx="120" cy="96" rx="80" ry="22" fill="#e7ead8" stroke="#333" stroke-width="2"/><ellipse cx="120" cy="80" rx="80" ry="22" fill="#cfd8c0" stroke="#333" stroke-width="2"/><path d="M104 60 q16 -18 32 0" fill="none" stroke="#333" stroke-width="4"/>',
"cfb":f'<g stroke="#caa" stroke-width="2" fill="#fdf7ef">{"".join(f"<path d=\'M40 {50+i*20} q20 -10 40 0 t40 0 t40 0 t40 0\' fill=none/>" for i in range(4))}</g><text x="120" y="150" font-size="13" text-anchor="middle" fill="{G}">ceramic fibre</text>',
"rw":f'<g stroke="#9a7" stroke-width="2" fill="#eef0ea">{"".join(f"<path d=\'M40 {50+i*20} q20 -10 40 0 t40 0 t40 0 t40 0\' fill=none/>" for i in range(4))}</g><text x="120" y="150" font-size="13" text-anchor="middle" fill="{G}">rock wool</text>',
"shell":f'<rect x="72" y="46" width="96" height="86" rx="4" fill="#dfe3e6" stroke="#333" stroke-width="2"/><rect x="60" y="64" width="12" height="18" fill="#bbb" stroke="#333"/><rect x="60" y="98" width="12" height="18" fill="#bbb" stroke="#333"/>',
"well":f'<rect x="112" y="36" width="16" height="104" rx="4" fill="#cfe0ef" stroke="{A}" stroke-width="2"/><path d="M120 140 v-96" stroke="{A2}" stroke-width="2"/><circle cx="120" cy="40" r="4" fill="{R}"/>',
"salt":f'<path d="M80 58 h80 l-8 78 h-64 z" fill="#fff" stroke="#333" stroke-width="2"/><path d="M80 58 h80 l-4 14 h-72 z" fill="#eaeaf2" stroke="#333" stroke-width="2"/><g fill="{Y}"><circle cx="100" cy="96" r="3"/><circle cx="120" cy="108" r="3"/><circle cx="138" cy="92" r="3"/><circle cx="112" cy="120" r="3"/></g>',
"core":f'<rect x="104" y="40" width="32" height="96" rx="4" fill="#777" stroke="#222" stroke-width="2"/><path d="M104 56 h32 M104 76 h32 M104 96 h32" stroke="#444" stroke-width="2"/>',
"scrap":f'<g fill="#8a8f93" stroke="#333" stroke-width="2"><circle cx="96" cy="100" r="26"/><circle cx="96" cy="100" r="8" fill="#fbfbfc"/><circle cx="150" cy="86" r="22"/><circle cx="150" cy="86" r="7" fill="#fbfbfc"/><rect x="120" y="118" width="40" height="18" rx="3"/></g>',
"sand":f'<path d="M60 128 q60 -60 120 0 z" fill="#f0e3bf" stroke="#caa66a" stroke-width="2"/><g fill="#b9a66b"><circle cx="110" cy="112" r="2"/><circle cx="130" cy="118" r="2"/><circle cx="120" cy="104" r="2"/></g>',
"pv":f'<rect x="56" y="44" width="128" height="84" fill="#2b4a7a" stroke="#1a2a44" stroke-width="2"/><g stroke="#5f82b8" stroke-width="2"><path d="M88 44 v84 M120 44 v84 M152 44 v84 M56 72 h128 M56 100 h128"/></g>',
"dc":f'<rect x="64" y="56" width="52" height="60" rx="4" fill="#eee" stroke="#333" stroke-width="2"/><text x="90" y="92" font-size="14" text-anchor="middle" fill="{A}">DC</text><rect x="128" y="56" width="48" height="60" rx="4" fill="#f4caca" stroke="#333" stroke-width="2"/><text x="152" y="92" font-size="12" text-anchor="middle" fill="{R}">SSR</text>',
"tc":f'<path d="M60 120 h60 l12 -12" fill="none" stroke="{A}" stroke-width="3"/><circle cx="60" cy="120" r="6" fill="{R}"/><path d="M132 108 l20 -20 m-20 20 l-20 -20" stroke="#333" stroke-width="3"/><text x="120" y="150" font-size="12" text-anchor="middle" fill="{G}">type-K</text>',
"logger":f'<rect x="64" y="52" width="112" height="72" rx="6" fill="#2b2f36" stroke="#111" stroke-width="2"/><rect x="74" y="62" width="92" height="40" rx="3" fill="#8fd6a0"/><g stroke="#2b2f36" stroke-width="2"><path d="M80 92 l12 -14 l10 8 l14 -18 l12 10 l16 -8"/></g><g fill="#ccc"><circle cx="82" cy="114" r="3"/><circle cx="96" cy="114" r="3"/><circle cx="110" cy="114" r="3"/></g>',
}
for k,b in icons.items():
    open(f"{k}.svg","w").write(card(b))
print(len(icons),"icons")
