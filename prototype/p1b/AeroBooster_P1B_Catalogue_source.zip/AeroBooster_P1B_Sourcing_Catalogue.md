# AeroBooster P1-B — Open Component Sourcing Catalogue

**For anyone who wants to build and measure the P1-B prototype.** Pair this with the P1-B manufacturing
specification and drawings. Each entry shows the part, its key specification, and **clickable links to live
offers** on international platforms (which ship worldwide) with examples for Egypt and Saudi Arabia.

*How to use:* the links open current listings or search pages — prices and sellers change, so confirm the
specification and shipping before you order. The pictures are **schematic illustrations** (not product
photos), so this document is free to copy and share. Prices are planning estimates, not endorsements of any
seller. For safety (nitrate salt is an oxidiser, DC wiring, hot surfaces), follow the P1-B manufacturing
specification.

**ملخص:** هذا كتالوج مكوّنات مفتوح لمن يريد بناء النموذج P1-B وقياسه بنفسه. لكل مكوّن صورة توضيحية ومواصفات
وروابط عروض حيّة من منصات دولية تشحن للعالم، مع أمثلة في مصر والسعودية. الروابط لعروض متغيّرة، فتحقّق من
المواصفة قبل الشراء. الصور تخطيطية لا فوتوغرافية كي يكون النشر حرًّا. الأسعار تقديرية. اتبع مواصفة التصنيع
للسلامة.

---

## Storage medium — two interchangeable fills / وسط التخزين — حشوتان متبادلتان

**The prototype is built once and can be filled two ways:** **P1-S** with nitrate solar salt, or **P1-X**
with scrap cast iron and sand. In transient simulation of this bench unit the scrap-iron + sand fill gave
results close to the salt fill, so where nitrate salt is scarce, costly, or unwanted as an oxidiser,
**iron + sand is a workable substitute — not identical.** Trade-offs: salt stores more energy per litre
and holds a flatter delivery temperature (it melts and stores latent heat); iron + sand store heat only by
warming up, so they need more mass and their output temperature falls as they discharge, but the materials
are cheap or free and carry no oxidiser hazard. These are simulation figures — building both fills is how
they are confirmed by measurement.

**يُبنى النموذج مرة واحدة ويُملأ بإحدى طريقتين:** **P1-S** بملح النترات الشمسي، أو **P1-X** بخردة الحديد
الزهر والرمل. أظهرت المحاكاة العابرة لهذه الوحدة المخبرية أن حشوة الخردة + الرمل تعطي نتائج قريبة من حشوة
الملح، لذا حيث يندر الملح أو يغلو أو لا يُرغب فيه كمؤكسِد فإن **الحديد + الرمل بديل عملي — لا مطابق.**
المقايضات: الملح يخزّن طاقة أكبر لكل لتر ويحافظ على حرارة تسليم أكثر ثباتًا (ينصهر فيخزّن حرارة كامنة)؛ أما
الحديد + الرمل فيخزّنان الحرارة بالتسخين فقط، فيحتاجان كتلة أكبر وتنخفض حرارة خرجهما مع التفريغ، لكن المادة
رخيصة أو مجانية وبلا خطر مؤكسِد. وهذه أرقام محاكاة، وبناء الحشوتين هو ما يؤكّدها بالقياس.

---

## A. Shared build items

### 1. Storage tank (fabricated) — خزان التخزين
![](icons/tank.png){ width=1.3in }
**Spec:** mild steel 3 mm, Ø300 × 200 mm, top flange OD 360 / PCD 330 / 8×M8. Full-penetration welds.
**الخزان:** فولاذ طري 3 مم، يُصنَّع في أي ورشة لحام.
**Source:** fabricate at any steel/welding workshop. Sheet: [Alibaba — mild steel sheet 3 mm](https://www.alibaba.com/trade/search?SearchText=3mm%20mild%20steel%20sheet).

### 2. Baking / contact plate (cast iron) — صاج الحديد الزهر
![](icons/plate.png){ width=1.3in }
**Spec:** grey cast iron, Ø300–330 × 12 mm, flat machined top. A 30 cm cast-iron comal/tawa/griddle is the closest off-the-shelf.
**الصاج:** حديد زهر Ø300–330، أو صاج/طاوة دائري 30 سم جاهز.
**Offers:** [BakeryBits — cast-iron tawa/comal 30 cm](https://www.bakerybits.co.uk/cast-iron-tawa-budare-comal-griddle-pan-12-30cm) · [Alibaba — cast-iron griddle](https://www.alibaba.com/discover/commerical-griddle.html) · [AliExpress — cast iron griddle 30 cm](https://www.aliexpress.com/w/wholesale-cast-iron-griddle-30cm.html) · Egypt/Saudi: [Ubuy EG](https://www.ubuy.com.eg/en/search?q=cast%20iron%20griddle%2030cm) · [Ubuy SA](https://www.ubuy.com.sa/en/search?q=cast%20iron%20griddle%2030cm).

### 3. Band heater 3.8 Ω (custom, low-voltage) — السخان الحزامي المخصّص
![](icons/band.png){ width=1.3in }
**Spec:** ceramic/mica band, ID Ø300 × 150 mm, **custom resistance 3.8 Ω ± 5 %**, sheath ≥ 450 °C, leads ≥ 4 mm². Order to your measured tank OD.
**السخان:** حزام سيراميك/ميكا مخصّص 3.8 أوم، غلاف ≥450 °م. يُطلب حسب قطر الخزان.
**Offers (ask for 3.8 Ω custom):** [Alibaba — ceramic band heater](https://www.alibaba.com/product-detail/1300W-Ceramic-Band-Heater-Industrial-Band_1600438726430.html) · [Yuheng — custom band heater 12–480 V](https://yuhengheating.en.alibaba.com) · [Alibaba — custom low-voltage band heater](https://www.alibaba.com/trade/search?SearchText=custom%20low%20voltage%20band%20heater).

### 4. Insulated lid — الغطاء المعزول
![](icons/lid.png){ width=1.3in }
**Spec:** SS304 2 + 2 mm sheets around a 30 mm ceramic-fibre board, Ø360, strap-held. Fabricate locally.
**الغطاء:** صفيحتا ستانلس حول لوح ألياف سيراميك 30 مم، يُصنَّع محليًا.

### 5. Ceramic fibre blanket 50 mm (1260 °C) — بطانية ألياف سيراميك
![](icons/cfb.png){ width=1.3in }
**Spec:** 50 mm, 1260 °C, ~128 kg/m³, ≈ 1 m² needed.
**العزل الداخلي:** ألياف سيراميك 50 مم تتحمل 1260 °م.
**Offers:** [Alibaba — 1260 °C 50 mm blanket](https://www.alibaba.com/trade/search?SearchText=1260%20ceramic%20fiber%20blanket%2050mm) · [Made-in-China](https://www.made-in-china.com/productdirectory.do?word=ceramic%20fiber%20blanket%201260) · [AliExpress](https://www.aliexpress.com/w/wholesale-ceramic-fiber-blanket-50mm.html).

### 6. Rock wool slab (100 + 50 mm) — الصوف الصخري
![](icons/rw.png){ width=1.3in }
**Spec:** mineral/rock wool slab, ~100 kg/m³. Buy locally (building-insulation shops).
**الصوف الصخري:** ألواح، من محلات عوازل البناء محليًا. [Alibaba — rock wool slab](https://www.alibaba.com/trade/search?SearchText=rock%20wool%20slab%20board).

### 7. Outer shell + buckle straps — الغلاف الخارجي
![](icons/shell.png){ width=1.3in }
**Spec:** galvanised sheet 0.6 mm + 2 stainless buckle straps. Fabricate locally.
**الغلاف:** صفيحة مجلفنة 0.6 مم ومشبكا شدّ، يُصنَّع محليًا.

### 8. Thermowells — جيوب المزدوجات الحرارية
![](icons/well.png){ width=1.3in }
**Spec:** closed-end stainless tube Ø10, 3 pcs, entered from the top.
**الجيوب:** أنابيب ستانلس مغلقة الطرف Ø10، ثلاثة.
**Offers:** [AliExpress — thermowell Ø10](https://www.aliexpress.com/w/wholesale-thermowell-tube.html) · [Alibaba](https://www.alibaba.com/trade/search?SearchText=closed%20end%20thermowell%20tube%2010mm).

---

## B. P1-S fill (salt)

### 9. Solar salt — KNO₃ + NaNO₃ (60/40) — ملح النترات
![](icons/salt.png){ width=1.3in }
**Spec:** ~20–23 kg, technical/fertiliser grade. KNO₃ is sold as fertiliser (13-0-46); NaNO₃ is Chile
saltpeter (16-0-0). Mix 60 % NaNO₃ / 40 % KNO₃ by mass.
**الملح:** ~20–23 كغ، نترات بوتاسيوم (سماد 13-0-46) + نترات صوديوم، خلط 60/40.
**Offers:** Egypt: [Ubuy EG — technical KNO₃](https://www.ubuy.com.eg/en/search?q=potassium%20nitrate%20technical) · Saudi: [Ubuy SA — KNO₃](https://www.ubuy.com.sa/en/search?q=potassium%20nitrate) · Bulk/agri: [Alibaba — agricultural KNO₃](https://www.alibaba.com/trade/search?SearchText=potassium%20nitrate%20agricultural) · local agricultural-input dealers.

### 10. Cast-iron core (P1-S heat path) — القلب الحديدي
![](icons/core.png){ width=1.3in }
**Spec:** cast iron Ø110 × ~120 mm, bolted to the plate, reaching 100 mm into the salt. Turn from bar or scrap at a machine shop.
**القلب:** حديد زهر Ø110 يُخرَط في ورشة أو من خردة.

---

## C. P1-X fill (iron + sand)

### 11. Scrap cast iron — خردة الحديد الزهر
![](icons/scrap.png){ width=1.3in }
**Spec:** ~35 kg washed scrap (e.g. brake discs / chunks). From any scrapyard; often near-free. Wash before use (brake dust).
**الخردة:** ~35 كغ أقراص فرامل/قطع، من ساحة خردة، تُغسل قبل الاستعمال.

### 12. Dry quartz sand — رمل جاف
![](icons/sand.png){ width=1.3in }
**Spec:** ~13 kg clean dry sand, dried fully before use. Local.
**الرمل:** ~13 كغ رمل نظيف جاف، محليًا.

---

## D. Shared test & electrical gear (buy once)

### 13. PV module ~592 W (72-cell) — اللوح الكهروضوئي
![](icons/pv.png){ width=1.3in }
**Spec:** ~590–600 W, Voc ≈ 52.5 V, Vmp ≈ 44.4 V. One module.
**اللوح:** ~592 واط، 72 خلية.
**Offers:** [Made-in-China — 590–600 W](https://www.made-in-china.com/productdirectory.do?word=590W%20solar%20panel) · [Alibaba — 590 W panel](https://www.alibaba.com/trade/search?SearchText=590W%20solar%20panel) · local solar distributors.

### 14. DC gear — isolator + breaker + SSR + watt-meter — عدة التيار المستمر
![](icons/dc.png){ width=1.3in }
**Spec:** DC-rated isolator, ≥20 A DC breaker, **DC-rated SSR (60 V / 40 A)** + plate thermostat, DC watt-meter. (AC-rated parts weld on DC — do not use them.)
**العدة:** عازل وقاطع ومرحّل مقنّنة للتيار المستمر، وعدّاد قدرة.
**Offers:** [Crydom DC60D40 (DC-rated SSR)](https://www.masterelectronics.com/en/sensata-crydom/dc60d40c-45158301.html) · [AliExpress — DC SSR 60 V](https://www.aliexpress.com/w/wholesale-DC-solid-state-relay-60V.html) · [AliExpress — DC MCB isolator](https://www.aliexpress.com/w/wholesale-DC-circuit-breaker-isolator.html) · [AliExpress — DC watt meter](https://www.aliexpress.com/w/wholesale-DC-watt-meter.html).

### 15. Thermocouples ×7 (type-K) — المزدوجات الحرارية
![](icons/tc.png){ width=1.3in }
**Spec:** 7 × type-K, MI/stainless-sheathed probes, 0–400 °C.
**المزدوجات:** سبع من نوع K بغلاف ستانلس.
**Offers:** [AliExpress — K-type probe](https://www.aliexpress.com/w/wholesale-k-type-thermocouple-probe.html) · [Alibaba](https://www.alibaba.com/trade/search?SearchText=k%20type%20thermocouple%20probe%20MI).

### 16. Thermocouple logger (≥7 channel) — مسجّل المزدوجات
![](icons/logger.png){ width=1.3in }
**Spec:** ≥7-channel K-type logger with PC/SD export. Budget: two 4-channel SD loggers; quality: Pico TC-08.
**المسجّل:** ≥7 قنوات K مع تصدير للحاسوب.
**Offers:** [Pico TC-08 (8-ch, quality)](https://www.picotech.com/data-logger/tc-08/thermocouple-data-logger) · [AliExpress — K-type data logger](https://www.aliexpress.com/w/wholesale-k-type-thermocouple-data-logger.html).

---

## Local fabrication & bulk materials

The tank, lid and outer shell are made at any **steel/welding workshop**; the cast-iron plate, core and
top disc at a **foundry or machine shop**; **salt** from agricultural-input dealers; **sand** and **scrap
iron** locally. Only the band heater, PV module and electronics usually ship from international platforms.

A **university mechanical/materials laboratory or a technical institute** can fabricate and instrument the
whole unit — share this catalogue together with the P1-B drawings and manufacturing specification.

*All offers and prices were current when compiled and will change; verify every specification before
ordering. Illustrations are schematic. This catalogue names no specific country of residence and endorses
no single seller.*
